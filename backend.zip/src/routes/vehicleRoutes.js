import express from "express";

import {
  addVehicle,
  filterData,
  getModelsByBrand,
  getVehicleBrands,
  getVehicles,
} from "../controllers/vehicleController.js";
import { upload } from "../utils/multerConfig.js";

export const vehicleRouter = express.Router();

vehicleRouter.post(
  "/vehicle",
  upload.fields([
    { name: "thumbnail", maxCount: 1 },
    { name: "vehicleimages", maxCount: 5 },
  ]),
  addVehicle
);
vehicleRouter.get("/vehicles", getVehicles);
vehicleRouter.get("/vehicles/filter/:brand", getModelsByBrand);
vehicleRouter.get("/vehicles/brands", getVehicleBrands);
vehicleRouter.get("/vehicles/filter", filterData);
