a = 12;
b=12;
console.log(a+b)